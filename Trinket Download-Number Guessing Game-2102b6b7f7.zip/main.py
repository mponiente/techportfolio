from random import randint

answer = randint(1 , 100)
tries = 10
running = True

while True:
  print("Guess a number between 1 and 100")
  print("(" + str(tries) + " guesses left)")
  guess = input(">")
  try:
    n = int(guess)
  except:
    print("Please give a valid number!")
    continue

  if n > answer:
    print("Too High!")
  elif n < answer:
    print("Too Low!")
  else:
    print("Correct")
    running = False
    
    
  tries -= 1
  if tries <= 0:
    print("GAME OVER!!!!!!!!!!!!!!!!!!!!!!")
    running = False
  