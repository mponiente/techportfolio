from processing import *


class Player:
  def __init__(self, x, y, c,  ctrl):
    self.ctrl = ctrl
    self.c = c
    self.x = x
    self.y = y
    self.r = 10
    self.dx = 0
    self.dy = 0
    self.bomb = False
    
  def update(self):
    self.dx = self.ctrl.dx
    self.dy = self.ctrl.dy
    destx = self.x + self.dx*5
    desty = self.y + self.dy*5
    c = get(destx, desty)
    if c != color(0):
      self.x = destx
      self.y = desty
    
      
  def draw(self):
    fill(self.c)
    ellipse(self.x, self.y, self.r * 2, self.r * 2)
    if self.bomb:
      fill(255)
      ellipse(self.x, self.y,self.r, self.r)
    
    
    
