from processing import *
from lvls import *
from controller import *
from player import Player
from random import choice

BOMB_TIME =  60 * 1000

ctrlArrows = ControllerArrows()
ctrlWASD = ControllerWASD()

prev_bomb_swap = 0


CHAR_WALL = "*"
CHAR_P1 = "1"
CHAR_P2 = "2"


def level_parse(s):
  lines = s.strip().split("\n")
  if len(lines) == 0:
    raise Exception("AHHH")
  return lines
  
def level_spawns(lines):
  ps = [None,None]
  h = len(lines)
  w = len(lines[0])
  tw = width/w
  th = height/h
  for y, line in enumerate(lines):
    for x, c in enumerate(line):
      if c == CHAR_P1:
        ps[0] = (int(tw*x), int(th*y))
      elif c == CHAR_P2:
        ps[1] = (int(tw*x), int(th*y))
  return ps


def level_draw(lines):
  h = len(lines)
  w = len(lines[0])
  tw = width/w
  th = height/h
  for y, line in enumerate(lines):
    for x, c in enumerate(line):
      if c == CHAR_WALL:
        fill(0)
        rect(x * tw, y * th, tw, th)
  

def setup():
  global level, p1, p2
  size(540, 540)
  level = level_parse(choice(all))
  spawns = level_spawns(level)
  p1 = Player(spawns[0][0],spawns[0][1], color(102,  0, 0), ctrlWASD)
  p2 = Player(spawns[1][0],spawns[1][1], color(0, 17, 51 ), ctrlArrows)
  choice([p1, p2]).bomb = True
  
  


def draw():
  global prev_bomb_swap
  
  ms = millis()
  time_left = max(BOMB_TIME - ms,0)
  
  if time_left == 0:
    background(0)
    fill(255)
    textSize(50)
    textAlign(CENTER, CENTER)
    text("GAME OVER",width//2,height//2-50)
    if p1.bomb:
      text("BLUE WINS", width//2,height//2+50)
    if p2.bomb:
      text("RED WINS",width//2,height//2+50)
    return
   
  background(255)
  
  ctrlArrows.update()
  ctrlWASD.update()

  level_draw(level) 
  p1.update()
  p2.update()
  
  d = ((p1.x-p2.x)**2 + (p1.y-p2.y)**2)**0.5
  if d < 10 and ms - prev_bomb_swap > 1000:
    p1.bomb = not p1.bomb
    p2.bomb = not p2.bomb
    prev_bomb_swap = ms
  
  p1.draw()
  p2.draw()
  
  fill(255, 153, 0)
  textSize(100)
  textAlign(CENTER,CENTER)
  text(time_left/1000,width//2,height//2)
  
  
  
def keyPressed():
  ctrlArrows.keyPressed()
  ctrlWASD.keyPressed()
  
def keyReleased():
  ctrlArrows.keyReleased()
  ctrlWASD.keyReleased()
  

run()
