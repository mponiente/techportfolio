from processing import *
import controller

LIMIT = 20
PADDLE_SPEED = 8
player_one_score = 0
player_two_score = 0
win = 0

wasd = controller.ControllerWASD()
arrows = controller.ControllerArrows()

def mid(a, b, c):
  if a <= b <= c or c <= b <= a:
    return b
  elif b <= a <= c or c <= a <= b:
    return a
  else:
    return c

 
  








# self. : x, y, w, h , c, dx, dy
class Ball():
  def __init__(self):
    self.r = 15
    self.x = width/2
    self.y = height/2
    self.dx = 0
    self.dy = 0
    self.c = color(255, 196, 0)
    
  def touching(self, p):
      
    return ( 
     self.y + self.r > p.y 
     and self.y - self.r < p.y + p.h
     and self.x + self. r > p.x
     and self.x - self.r < p.x + p.w
    )
    
  def reset(self):
    self.x = width/2
    self.y = height/2
    self.dx = 0
    self.dy = 0    
    
    
  def update(self):
    global player_one_score, player_two_score,win
    for g in goals:
      if self.touching(g):
        if g.n == 1:
          player_two_score += 1
          if player_two_score >= LIMIT:
            win = 2
          self.reset()
        elif g.n == 2:
          player_one_score += 1
          if player_one_score >= LIMIT:
            win = 1
          self.reset()
    for p in players:
      if self.touching(p):
        self.dx = 1 if p.n == 1 else -1
        self.dy = p.ctrl.dy
    self.x += self.dx * 7
    self.y += self.dy * 7
    
    if self.x < 0:
      self.dx = 1
    if self.x >= width:
      self.dx = -1
    if self.y < 0:
      self.dy = 1
    if self.y >= height:
      self.dy = -1
      
    
  def draw(self):
    fill(self.c)
    ellipse(self.x, self.y, self.r*2, self.r*2)
    
  

class Player():
  def __init__(self, n):
    self.n = n
    self.w = 20
    self.h = 80
    self.y = height/2 - self.h/2
    if n == 1:
      self.x = 20
      self.c = color(252, 136, 3)
      self.ctrl = wasd
    elif n == 2:
      self.x = width - self.w - 20
      self.c = color(3, 173, 252)
      self.ctrl = arrows
      

  def draw(self):
    fill(self.c)
    rect(self.x, self.y, self.w, self.h, )



  def update(self):
    self.x = mid(0, width- self.w, self.x + self.ctrl.dx * PADDLE_SPEED)
    self.y = mid(0, height - self.h,self.y + self.ctrl.dy * PADDLE_SPEED)
    


class Goal():
  def __init__(self, n):
    self.n = n
    self.w = 20
    self.h = 20
    self.c = color(255)
    if n == 1:
      self.x = 0
      self.y = height - self.h
    elif n == 2:
      self.x = width - self.w
      self.y = 0
  
  def draw(self):
    fill(self.c)
    rect(self.x, self.y, self.w, self.h)
    

def setup():
  global players, ball, goals
  size(400,400)
  players = [Player(1), Player(2)]
  goals = [Goal(1), Goal(2)]
  ball = Ball()
  
  
def draw():
  # backgrounds
  noStroke()
  fill(235, 200, 141)
  rect(0,0, width/2, height)
  fill(0, 174, 184)
  rect(width/2,0, width/2, height)
  
  # score
  fill(255,221, 171)
  textSize(160)
  text(player_one_score, 60, height - 130)
  fill(82, 212, 255)
  text(player_two_score, width - 173, height - 130)
  
  
  if win > 0:
    if win == 1:
      textSize(50)
      fill(255)
      text("Player 1 wins!", 50, 50)

    elif win == 2:
      textSize(50)
      fill(255)
      text("Player 2 wins!", 50, 50)
    return  
  
  
  stroke(1)
  
  
  wasd.update()
  arrows.update()
  
  #UPDATE
  ball.update()
  for p in players:
    p.update()
  
  #DRAW
  ball.draw()
  for g in goals:
    g.draw()
  for p in players:
    p.draw()
  


def keyPressed():
  wasd.keyPressed()
  arrows.keyPressed()
  
def keyReleased():
  wasd.keyReleased()
  arrows.keyReleased()



run()