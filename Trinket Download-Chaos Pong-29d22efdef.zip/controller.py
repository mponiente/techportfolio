from processing import key, keyCode, UP, DOWN, LEFT, RIGHT


class Controller():
  def __init__(self, keyMap):
    self.dx = 0
    self.dy = 0
    self.keys = set()
    self.keyMap = keyMap
  
  def update(self):
    self.dx = int((1, 0) in self.keys) - int((-1, 0) in self.keys) 
    self.dy = int((0, 1) in self.keys) - int((0, -1) in self.keys) 
    
  def keyPressed(self):
    if key in self.keyMap:
      self.keys.add(self.keyMap[key])
    elif keyCode in self.keyMap:
      self.keys.add(self.keyMap[keyCode])

  def keyReleased(self):
    if key in self.keyMap:
      self.keys.remove(self.keyMap[key])
    elif keyCode in self.keyMap:
      self.keys.remove(self.keyMap[keyCode])


def ControllerWASD():
  return Controller({'a': (-1, 0), 'd': (1, 0), 'w': (0, -1), 's': (0, 1)})

def ControllerArrows():
  return Controller({LEFT: (-1, 0), RIGHT: (1, 0), UP: (0, -1), DOWN: (0, 1)})
  