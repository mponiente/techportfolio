from processing import *

class Bullet:
  def __init__(self,x,y):
    self.x = x + 24.57
    self.y = y
    self.w = 20
    self.h = 20
    
  def draw(self, bullets, r,g, b ):
    fill(r ,g,b)
    ellipse(self.x, self.y, self. w, self. h)

  def move(self,bullets):
    self.y -= 4.17
    if self.y < 0 :
      bullets.remove(self)
    
class EnemyBullet(Bullet):
  def __init__(self, x, y):
    super(EnemyBullet, self).__init__(x,y)
    
  def move(self, bullets):
    self.y += 3.5
    if self.y > height:
      bullets.remove(self)
    

class Spaceship:
  def __init__(self):
    self.x = width/2
    self.y = height - 100
    self.h = 100
    self.w = 50
    self.img = loadImage("F5S4.png")
    self.lives = 25
    self.bullets = []
    

  def draw(self):
    image(self.img, self.x, self.y, self.w, self.h)
    textSize(20)
    fill(255)
    text("Lives" + str(self.lives), 50, 50)
    self.move()
    self.fire()
    for bullet in self.bullets:
      bullet.draw(self.bullets,0, 255, 0)
      bullet.move(self.bullets)
      
  def move(self):
    if keyPressed:
      if keyCode == LEFT:
        self.x -=6
      elif keyCode == RIGHT:
        self.x +=6
    if self.x <0 :
      self.x = 0
    elif self.x + self.w > width:
      self.x = height- self.w
      
  def detect(self, bullets):
    global play
    for bullet in bullets:
      if bullet.x - bullet.w/2 < self.x +self.w and bullet.x +bullet.w/2 > self.x:
        if bullet.y - bullet.h/2 <self.y +self.h and bullet.y +bullet.h/2> self.y:
          self.lives -=1
          bullets.remove(bullet)
          
    if self.lives <= 0:
      play = False
      textSize(50)
      text("GAME OVER", width/2 -80, height/2)
      
  def fire(self):
    if keyPressed:
      if key ==" ":
        if frameCount %  7 ==0:
          self.bullets.append(Bullet(self.x, self.y))
        
        
class Enemy:
  def __init__(self):
    self.x = random(0, width - 86)
    self.y = random(0, height/3)
    self.w = 86
    self.h = 100
    self.img = loadImage("pWQXRoM.png")
    self.lives = 30
    self.bullets = []
    
    
    
  def draw(self):
    image(self.img, self.x, self.y, self.w, self.h)
    self.fire()
    for bullet in self.bullets:
      bullet.draw(self.bullets, 255, 0, 0)
      bullet.move(self.bullets)
    
  def detect(self, bullets):
    global enemy 
    for bullet in bullets:
      if bullet.x - bullet.w/2 < self.x +self.w and bullet.x +bullet.w/2 > self.x:
        if bullet.y - bullet.h/2 <self.y +self.h and bullet.y +bullet.h/2> self.y:
          self.lives -=1
          bullets.remove(bullet)
          
    if self.lives <= 0:
      enemy = Enemy()
    
  def fire(self):
    if frameCount %  60 ==0:
      self.bullets.append(EnemyBullet(self.x + 18, self.y + 18))
      
      
        
def setup():
  global ship, enemy , play
  size(600,600)
  ship = Spaceship()
  enemy = Enemy()
  play = True        
  
def draw():
  background(50,123,168)
  if play == True:
    ship.draw()
    enemy.draw()
  
  enemy.detect(ship.bullets)
  ship.detect(enemy.bullets)
  

  


run()
  